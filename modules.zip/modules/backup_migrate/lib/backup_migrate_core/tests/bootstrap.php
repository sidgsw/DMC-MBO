<?php
ini_set('error_reporting', E_ALL);

include 'vendor/autoload.php';
